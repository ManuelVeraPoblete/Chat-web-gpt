import { Injectable, signal } from '@angular/core';

import { WorkStatus } from '../../domain/value-objects/work-status.vo';
import { WorkdayAction } from '../../domain/value-objects/workday-action.vo';
import type { WorkdayDto } from '../../domain/models/workday-dto.model';

import { ConnectSessionUseCase } from '../use-cases/connect-session.usecase';
import { SetWorkStatusUseCase } from '../use-cases/set-work-status.usecase';
import { SendMessageUseCase } from '../use-cases/send-message.usecase';
import { GetTodayWorkdayUseCase } from '../use-cases/get-today-workday.usecase';

/**
 * ✅ ChatShellFacade
 *
 * Responsabilidades (SRP):
 * - Sincronizar estado laboral del usuario autenticado con backend
 * - Exponer signals para UI (status, loading, lastError)
 * - Delegar envío de mensajes de chat a su caso de uso
 *
 * Nota:
 * La lógica de transiciones NO vive aquí (evitamos reglas hardcodeadas),
 * el backend es la fuente de verdad y además existe un "RESET" explícito
 * para tolerancia a errores humanos.
 */
@Injectable({ providedIn: 'root' })
export class ChatShellFacade {
  /**
   * ✅ Estado laboral actual del usuario
   */
  readonly status = signal<WorkStatus>(WorkStatus.NOT_STARTED);

  /**
   * ✅ Loading de estado laboral (UX)
   */
  readonly loadingWorkday = signal<boolean>(false);

  /**
   * ✅ Último error de negocio/UI (para mostrar snackbars)
   */
  readonly lastError = signal<string | null>(null);

  constructor(
    private readonly connectUC: ConnectSessionUseCase,
    private readonly actionUC: SetWorkStatusUseCase,
    private readonly sendUC: SendMessageUseCase,
    private readonly todayUC: GetTodayWorkdayUseCase,
  ) {}

  /**
   * =====================================================
   * ✅ Sincroniza estado laboral del día desde backend
   * =====================================================
   */
  loadToday(): void {
    this.loadingWorkday.set(true);
    this.lastError.set(null);

    this.todayUC.execute().subscribe({
      next: (dto: WorkdayDto) => {
        this.status.set((dto?.status as WorkStatus) ?? WorkStatus.NOT_STARTED);
      },
      error: (err) => {
        console.warn('[ChatShellFacade] loadToday error:', err);
        this.status.set(WorkStatus.NOT_STARTED);
        this.lastError.set('No se pudo cargar tu estado laboral de hoy.');
      },
      complete: () => this.loadingWorkday.set(false),
    });
  }

  /**
   * =====================================================
   * ✅ Acciones (Commands)
   * =====================================================
   */

  connect(): void {
    this.perform(WorkdayAction.CONNECT);
  }

  pause(): void {
    this.perform(WorkdayAction.PAUSE);
  }

  lunch(): void {
    this.perform(WorkdayAction.LUNCH);
  }

  resume(): void {
    this.perform(WorkdayAction.RESUME);
  }

  disconnect(): void {
    this.perform(WorkdayAction.DISCONNECT);
  }

  reset(): void {
    this.perform(WorkdayAction.RESET);
  }

  /**
   * Ejecuta una acción y sincroniza el status resultante.
   */
  perform(action: WorkdayAction): void {
    this.lastError.set(null);

    const obs =
      action === WorkdayAction.CONNECT
        ? this.connectUC.execute()
        : this.actionUC.execute(action);

    obs.subscribe({
      next: (dto: WorkdayDto) => {
        this.status.set((dto?.status as WorkStatus) ?? this.status());
      },
      error: (err) => {
        console.warn('[ChatShellFacade] perform error:', err);

        const msg =
          err?.error?.message ||
          err?.message ||
          'No se pudo ejecutar la acción.';

        this.lastError.set(String(msg));
      },
    });
  }

  /**
   * =====================================================
   * ✅ Enviar mensaje de chat
   * =====================================================
   */
  sendMessage(peerId: string, content: string) {
    return this.sendUC.execute(peerId, content);
  }
}
