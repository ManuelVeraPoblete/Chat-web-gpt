import { Injectable, computed, signal } from '@angular/core';
import { firstValueFrom } from 'rxjs';

import { UsersRepositoryHttp } from '../data/users.repository.http';
import { UnreadRepositoryHttp } from '../data/unread.repository.http';

import { GetTodayWorkdayStatusesUseCase } from './use-cases/get-today-workday-statuses.usecase';

import type { AppUser } from '../domain/models/app-user.model';
import type { WorkdayDto } from '../domain/models/workday-dto.model';
import { WorkStatus } from '../domain/value-objects/work-status.vo';

/**
 * ✅ UsersSidebarFacade
 * Responsabilidad (SRP):
 * - Cargar usuarios
 * - Cargar contadores de no leídos (unread)
 * - Cargar estados laborales del día (hoy) para cada usuario (dot + contadores)
 *
 * Notas de robustez:
 * - Si falla unread, no rompe el resto.
 * - Si falla status, hace fallback a NOT_STARTED para todos.
 * - Normaliza distintas formas de respuesta del backend.
 */
@Injectable({ providedIn: 'root' })
export class UsersSidebarFacade {
  private readonly usersSig = signal<AppUser[]>([]);
  private readonly unreadSig = signal<Record<string, number>>({});
  private readonly loadingSig = signal(false);

  /**
   * Mapa userId -> WorkStatus (hoy)
   */
  private readonly statusSig = signal<Record<string, WorkStatus>>({});

  // Exposición reactiva (signals)
  users = computed(() => this.usersSig());
  unread = computed(() => this.unreadSig());
  loading = computed(() => this.loadingSig());
  statuses = computed(() => this.statusSig());

  /**
   * ✅ Contadores por estado (para la leyenda)
   */
  statusCounts = computed(() => {
    const users = this.usersSig();
    const map = this.statusSig();

    let active = 0;
    let paused = 0;
    let lunch = 0;
    let ended = 0;

    for (const u of users) {
      const st = map[u.id] ?? WorkStatus.NOT_STARTED;

      if (st === WorkStatus.ACTIVE) active++;
      else if (st === WorkStatus.PAUSED) paused++;
      else if (st === WorkStatus.LUNCH) lunch++;
      else if (st === WorkStatus.ENDED) ended++;
      // NOT_STARTED no se cuenta en la leyenda (puedes agregarlo si quieres)
    }

    return { active, paused, lunch, ended };
  });

  constructor(
    private readonly usersRepo: UsersRepositoryHttp,
    private readonly unreadRepo: UnreadRepositoryHttp,
    private readonly statusesUC: GetTodayWorkdayStatusesUseCase,
  ) {}

  /**
   * ✅ Carga todo:
   * - users
   * - unread counts
   * - workday statuses
   */
  async load(): Promise<void> {
    this.loadingSig.set(true);

    try {
      // 1) Users
      const users = await this.usersRepo.getAll();
      this.usersSig.set(users ?? []);

      const ids = (users ?? []).map((u) => u.id).filter(Boolean);

      // 2) Unread (si falla, no corta el flujo)
      try {
        const counts = await this.unreadRepo.getUnreadCounts(ids);
        this.unreadSig.set(counts ?? {});
      } catch (e) {
        console.warn('[UsersSidebarFacade] No se pudieron cargar unreadCounts', e);
        this.unreadSig.set({});
      }

      // 3) Statuses (si falla, fallback NOT_STARTED)
      const statuses = await this.loadStatuses(ids);
      this.statusSig.set(statuses);
    } finally {
      this.loadingSig.set(false);
    }
  }

  /**
   * ✅ Estado laboral de un usuario (fallback NOT_STARTED)
   */
  getStatus(userId: string): WorkStatus {
    return this.statusSig()[userId] ?? WorkStatus.NOT_STARTED;
  }

  /**
   * ✅ Recupera estados del día en masa, robusto.
   *
   * Soporta respuestas tipo:
   * - Record<string, WorkdayDto>
   * - { data: Record<string, WorkdayDto> }
   * - Array<WorkdayDto>
   */
  private async loadStatuses(userIds: string[]): Promise<Record<string, WorkStatus>> {
    if (!Array.isArray(userIds) || userIds.length === 0) return {};

    try {
      const raw = await firstValueFrom(this.statusesUC.execute(userIds));

      // ✅ Normaliza posibles formas de respuesta
      const map = this.normalizeStatusesResponse(raw);

      const res: Record<string, WorkStatus> = {};
      for (const [id, dto] of Object.entries(map)) {
        res[id] = this.coerceStatus(dto?.status);
      }

      // ✅ Asegura que todos los ids tengan valor (fallback)
      for (const id of userIds) {
        if (!res[id]) res[id] = WorkStatus.NOT_STARTED;
      }

      return res;
    } catch (e) {
      console.warn('[UsersSidebarFacade] No se pudieron cargar estados /workday/today/statuses', e);

      // ✅ fallback: todos NOT_STARTED
      const fallback: Record<string, WorkStatus> = {};
      for (const id of userIds) fallback[id] = WorkStatus.NOT_STARTED;
      return fallback;
    }
  }

  /**
   * ✅ Convierte cualquier respuesta del backend a Record<userId, WorkdayDto>
   */
  private normalizeStatusesResponse(raw: unknown): Record<string, WorkdayDto> {
    // Caso 1: { data: {...} }
    if (raw && typeof raw === 'object' && 'data' in (raw as any)) {
      const data = (raw as any).data;
      if (data && typeof data === 'object') return data as Record<string, WorkdayDto>;
    }

    // Caso 2: Record<string, WorkdayDto>
    if (raw && typeof raw === 'object' && !Array.isArray(raw)) {
      return raw as Record<string, WorkdayDto>;
    }

    // Caso 3: Array<WorkdayDto>
    if (Array.isArray(raw)) {
      const out: Record<string, WorkdayDto> = {};
      for (const item of raw) {
        const dto = item as WorkdayDto;
        if (dto?.userId) out[dto.userId] = dto;
      }
      return out;
    }

    return {};
  }

  /**
   * ✅ Coerción segura al enum del front.
   * Si llega algo desconocido, cae a NOT_STARTED.
   *
   * Importante: el backend puede mandar mayúsculas ya, pero no dependemos de eso.
   */
  private coerceStatus(input: unknown): WorkStatus {
    const v = String(input ?? '').toUpperCase();

    if (v === WorkStatus.ACTIVE) return WorkStatus.ACTIVE;
    if (v === WorkStatus.PAUSED) return WorkStatus.PAUSED;
    if (v === WorkStatus.LUNCH) return WorkStatus.LUNCH;
    if (v === WorkStatus.ENDED) return WorkStatus.ENDED;

    return WorkStatus.NOT_STARTED;
  }
}
