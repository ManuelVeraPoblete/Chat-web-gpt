export const environment = {
  production: true,

  /**
   * En producción cambia a tu dominio/https.
   * Ej: https://api.corpchat.cl
   */
  apiBaseUrl: 'http://192.168.1.28:3000',
};
