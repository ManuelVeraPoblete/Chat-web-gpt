export const environment = {
  production: false,

  /**
   * URL base de tu API (igual a RN)
   * IMPORTANTE: en web normalmente será una IP o dominio.
   */
  apiBaseUrl: 'http://192.168.1.28:3000',
};
