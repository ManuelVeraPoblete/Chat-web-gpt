/**
 * DTOs alineados al backend (Mongo + timestamps + attachments discriminados).
 * Fuente: src/modules/chat/schemas/message.schema.ts
 */

export type ChatAttachmentKindDto = 'IMAGE' | 'FILE' | 'LOCATION';

export type ChatAttachmentDto = {
  id: string;
  kind: ChatAttachmentKindDto;

  // IMAGE / FILE
  url?: string;
  fileName?: string;
  mimeType?: string;
  fileSize?: number;
  width?: number | null;
  height?: number | null;

  // LOCATION
  latitude?: number;
  longitude?: number;
  label?: string | null;
};

export type ChatMessageDto = {
  _id: string;
  conversationId: string;

  senderId: string;
  role: 'user' | 'assistant';

  text: string;
  attachments: ChatAttachmentDto[];

  createdAt: string;
  updatedAt: string;
};
