import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

import type { ChatRepository, SendMessageInput } from '../domain/ports/chat.repository';
import type { ChatMessage } from '../domain/models/chat-message.model';
import type { ChatMessageDto, ChatAttachmentDto } from './dtos/chat.dto';

/**
 * ChatRepositoryHttp (alineado al backend)
 * - GET /chat/:peerId/messages?limit=200
 * - POST /chat/:peerId/messages
 *    - JSON: { text, location?: { latitude, longitude, label? } }
 *    - multipart: text + location(JSON string) + files[]
 */
@Injectable({ providedIn: 'root' })
export class ChatRepositoryHttp implements ChatRepository {
  constructor(private readonly http: HttpClient) {}

  async getMessages(peerId: string, limit: number): Promise<ChatMessage[]> {
    const res = await firstValueFrom(
      this.http.get<ChatMessageDto[]>(`/chat/${encodeURIComponent(peerId)}/messages`, {
        params: { limit: String(limit) },
      })
    );

    const dtoList = Array.isArray(res) ? res : [];
    return dtoList.map((dto) => this.mapMessageDto(peerId, dto));
  }

  async sendMessage(peerId: string, input: SendMessageInput): Promise<ChatMessage> {
    const hasFiles = (input.files?.length ?? 0) > 0;
    const hasLocation = !!input.location;
    const text = input.text?.trim() ?? '';

    // ✅ Multipart si hay archivos (y/o location)
    if (hasFiles || hasLocation) {
      const form = new FormData();

      // text opcional
      if (text) form.append('text', text);

      // files (backend espera key "files")
      for (const f of input.files ?? []) {
        form.append('files', f, f.name);
      }

      // location: backend espera "location" como JSON string en multipart
      if (input.location) {
        const loc = {
          latitude: input.location.lat,
          longitude: input.location.lng,
        };
        form.append('location', JSON.stringify(loc));
      }

      const res = await firstValueFrom(
        this.http.post<ChatMessageDto>(`/chat/${encodeURIComponent(peerId)}/messages`, form)
      );

      return this.mapMessageDto(peerId, res);
    }

    // ✅ Solo texto => JSON
    const body: any = { text };

    // (opcional) si quieres soportar location también por JSON:
    if (input.location) {
      body.location = {
        latitude: input.location.lat,
        longitude: input.location.lng,
      };
    }

    const res = await firstValueFrom(
      this.http.post<ChatMessageDto>(`/chat/${encodeURIComponent(peerId)}/messages`, body)
    );

    return this.mapMessageDto(peerId, res);
  }

  // ---------------------------------------
  // Mapper DTO -> Domain (UI-friendly)
  // ---------------------------------------
  private mapMessageDto(peerId: string, dto: ChatMessageDto): ChatMessage {
    const attachments = (dto.attachments ?? [])
      .map((a) => this.mapAttachment(peerId, a))
      .filter(Boolean) as NonNullable<ChatMessage['attachments']>;

    // Location: viene como attachment kind=LOCATION
    const locAtt = (dto.attachments ?? []).find((a) => a.kind === 'LOCATION');
    const location =
      locAtt && typeof locAtt.latitude === 'number' && typeof locAtt.longitude === 'number'
        ? { lat: locAtt.latitude, lng: locAtt.longitude }
        : undefined;

    return {
      id: dto._id,
      peerId,
      senderId: dto.senderId,
      text: dto.text || undefined,
      createdAt: dto.createdAt,
      attachments: attachments.length ? attachments : undefined,
      location,
    };
  }

  private mapAttachment(peerId: string, a: ChatAttachmentDto) {
    // Solo renderizamos links para IMAGE/FILE (LOCATION se renderiza aparte)
    if (a.kind === 'LOCATION') return null;

    // backend guarda url (probablemente /uploads/chat/xxx)
    const url = a.url;
    if (!url) return null;

    return {
      url, // puede ser relativo; lo abrimos igual (same origin + baseUrl depende del servidor)
      filename: a.fileName,
      mimeType: a.mimeType,
      sizeBytes: a.fileSize,
    };
  }
}
