/**
 * Attachment normalizado para la UI.
 * Suposición mínima: el backend expone una URL pública (ej /uploads/...)
 */
export type ChatAttachment = {
  url: string;          // URL absoluta o relativa (la UI la renderiza como link)
  filename?: string;    // nombre original
  mimeType?: string;    // image/png, application/pdf, etc.
  sizeBytes?: number;
};
