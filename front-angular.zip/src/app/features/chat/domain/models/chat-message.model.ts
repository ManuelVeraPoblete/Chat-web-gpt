import type { ChatAttachment } from './chat-attachment.model';

/**
 * Mensaje normalizado para la app web.
 */
export type ChatMessage = {
  id: string;
  peerId: string;        // usuario con quien converso (param userId)
  senderId: string;      // id del emisor
  text?: string;
  createdAt: string;     // ISO string para mostrar con DatePipe
  attachments?: ChatAttachment[];
  location?: { lat: number; lng: number };
};
