import type { ChatMessage } from '../models/chat-message.model';

export type SendMessageInput = {
  text?: string;
  files?: File[];
  location?: { lat: number; lng: number };
};

export type ChatRepository = {
  getMessages(peerId: string, limit: number): Promise<ChatMessage[]>;
  sendMessage(peerId: string, input: SendMessageInput): Promise<ChatMessage>;
};
