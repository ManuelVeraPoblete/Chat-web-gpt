import { Injectable, computed, signal } from '@angular/core';
import type { ChatMessage } from '../domain/models/chat-message.model';
import type { SendMessageInput } from '../domain/ports/chat.repository';
import { ChatRepositoryHttp } from '../data/chat.repository.http';
import { AuthFacade } from '../../auth/application/auth.facade';

/**
 * ChatFacade (profesional, sin romper backend):
 * - Backend NO expone websocket para chat -> usamos polling controlado SOLO mientras el chat está abierto.
 * - Merge por ID para evitar duplicados.
 */
@Injectable({ providedIn: 'root' })
export class ChatFacade {
  private readonly peerIdSig = signal<string>('');
  private readonly messagesSig = signal<ChatMessage[]>([]);
  private readonly loadingSig = signal(false);
  private readonly sendingSig = signal(false);

  peerId = computed(() => this.peerIdSig());
  messages = computed(() => this.messagesSig());
  loading = computed(() => this.loadingSig());
  sending = computed(() => this.sendingSig());

  myUserId = computed(() => this.auth.session()?.user.id ?? '');

  // polling control
  private pollTimer: number | null = null;
  private pollInFlight = false;

  constructor(
    private readonly repo: ChatRepositoryHttp,
    private readonly auth: AuthFacade
  ) {}

  async init(peerId: string): Promise<void> {
    this.peerIdSig.set(peerId);
    await this.loadHistory(200);

    // ✅ Polling suave: 3s (ajustable)
    this.startPolling(3000);
  }

  dispose(): void {
    this.stopPolling();
  }

  async loadHistory(limit = 200): Promise<void> {
    const peerId = this.peerIdSig();
    if (!peerId) return;

    this.loadingSig.set(true);
    try {
      const list = await this.repo.getMessages(peerId, limit);

      // backend puede venir DESC (por índice createdAt:-1). Normalizamos ASC para UI.
      const sorted = [...list].sort((a, b) => a.createdAt.localeCompare(b.createdAt));
      this.messagesSig.set(sorted);
    } finally {
      this.loadingSig.set(false);
    }
  }

  async send(input: SendMessageInput): Promise<void> {
    const peerId = this.peerIdSig();
    if (!peerId) return;

    const hasText = !!input.text?.trim();
    const hasFiles = (input.files?.length ?? 0) > 0;
    const hasLoc = !!input.location;

    if (!hasText && !hasFiles && !hasLoc) return;

    this.sendingSig.set(true);

    // ✅ Optimistic insert
    const optimisticId = `optimistic-${crypto.randomUUID()}`;
    const optimistic: ChatMessage = {
      id: optimisticId,
      peerId,
      senderId: this.myUserId() || 'me',
      createdAt: new Date().toISOString(),
      text: input.text?.trim() || undefined,
      location: input.location,
    };

    this.messagesSig.set([...this.messagesSig(), optimistic]);

    try {
      const saved = await this.repo.sendMessage(peerId, input);

      // Replace optimistic
      const next = this.messagesSig().map((m) => (m.id === optimisticId ? saved : m));
      this.messagesSig.set(next);
    } catch (e) {
      // rollback
      this.messagesSig.set(this.messagesSig().filter((m) => m.id !== optimisticId));
      throw e;
    } finally {
      this.sendingSig.set(false);
    }
  }

  // ---------------------------------------
  // Polling (realtime sin WS)
  // ---------------------------------------
  private startPolling(intervalMs: number): void {
    this.stopPolling();

    this.pollTimer = window.setInterval(async () => {
      if (this.pollInFlight) return;

      const peerId = this.peerIdSig();
      if (!peerId) return;

      this.pollInFlight = true;
      try {
        const latest = await this.repo.getMessages(peerId, 200);

        // Merge por id
        const current = this.messagesSig();
        const byId = new Map<string, ChatMessage>(current.map((m) => [m.id, m]));

        for (const m of latest) {
          if (!byId.has(m.id)) {
            byId.set(m.id, m);
          }
        }

        // Re-orden ASC
        const merged = Array.from(byId.values()).sort((a, b) => a.createdAt.localeCompare(b.createdAt));

        // Evitar set innecesario si no cambió (micro-optimización)
        if (merged.length !== current.length) {
          this.messagesSig.set(merged);
        }
      } catch {
        // silencioso: no hacemos spam de snackbars por polling
      } finally {
        this.pollInFlight = false;
      }
    }, intervalMs);
  }

  private stopPolling(): void {
    if (this.pollTimer) {
      window.clearInterval(this.pollTimer);
      this.pollTimer = null;
    }
    this.pollInFlight = false;
  }
}
