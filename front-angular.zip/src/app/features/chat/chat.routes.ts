import { Routes } from '@angular/router';
import { ChatPage } from './presentation/chat/chat.page';

export const CHAT_ROUTES: Routes = [
  { path: '', component: ChatPage },
];
