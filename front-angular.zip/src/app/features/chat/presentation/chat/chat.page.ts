import {
  AfterViewInit,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild,
  inject,
  signal,
} from '@angular/core';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { DatePipe, NgFor, NgIf } from '@angular/common';

import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTooltipModule } from '@angular/material/tooltip';

import { PageShellComponent } from '../../../../shared/ui/page-shell/page-shell.component';
import { ChatFacade } from '../../application/chat.facade';

/**
 * ChatPage (equivalente a ChatScreen RN)
 * - historial
 * - envío texto
 * - adjuntos (File input)
 * - ubicación (Geolocation web)
 * - "realtime" por polling (porque backend chat es REST)
 */
@Component({
  standalone: true,
  selector: 'cc-chat-page',
  imports: [
    RouterModule,
    NgIf,
    NgFor,
    DatePipe,
    PageShellComponent,

    MatCardModule,
    MatIconModule,
    MatButtonModule,
    MatProgressBarModule,
    MatSnackBarModule,
    MatTooltipModule,
  ],
  templateUrl: './chat.page.html',
  styleUrl: './chat.page.scss',
})
export class ChatPage implements OnInit, AfterViewInit, OnDestroy {
  // ✅ Inyección segura en propiedades (evita "used before initialization")
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly facade = inject(ChatFacade);
  private readonly snack = inject(MatSnackBar);

  // ✅ Alias para template (si quieres mantener "vm")
  readonly vm = this.facade;

  peerId = '';
  title = 'Chat';

  draft = signal('');
  selectedFiles = signal<File[]>([]);
  attachedLocation = signal<{ lat: number; lng: number } | null>(null);

  private readonly scrollTick = 120; // ms
  private scrollTimer?: number;

  @ViewChild('messagesBox') messagesBox?: ElementRef<HTMLDivElement>;
  @ViewChild('fileInput') fileInput?: ElementRef<HTMLInputElement>;

  async ngOnInit(): Promise<void> {
    this.peerId = this.route.snapshot.paramMap.get('userId') ?? '';
    this.title = `Chat`;

    if (!this.peerId) {
      await this.router.navigateByUrl('/home');
      return;
    }

    try {
      await this.facade.init(this.peerId);
      this.scheduleScrollToBottom();
    } catch (e: any) {
      this.snack.open(e?.message ?? 'No fue posible cargar el chat', 'Cerrar', { duration: 3500 });
    }
  }

  ngAfterViewInit(): void {
    this.scheduleScrollToBottom();
  }

  ngOnDestroy(): void {
    if (this.scrollTimer) window.clearTimeout(this.scrollTimer);

    // ✅ importante: detener polling/listeners del chat
    this.facade.dispose();
  }

  // ----------------------------
  // UI actions
  // ----------------------------
  back(): void {
    this.router.navigateByUrl('/home');
  }

  openFilePicker(): void {
    this.fileInput?.nativeElement.click();
  }

  onFilesSelected(evt: Event): void {
    const input = evt.target as HTMLInputElement;
    const files = input.files ? Array.from(input.files) : [];
    this.selectedFiles.set(files);

    // Limpiar input para permitir re-seleccionar el mismo archivo
    if (this.fileInput?.nativeElement) this.fileInput.nativeElement.value = '';
  }

  clearFiles(): void {
    this.selectedFiles.set([]);
  }

  async attachLocation(): Promise<void> {
    if (!navigator.geolocation) {
      this.snack.open('Geolocalización no soportada en este navegador', 'Cerrar', { duration: 3000 });
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        this.attachedLocation.set({ lat, lng });
        this.snack.open('Ubicación adjuntada', 'OK', { duration: 2000 });
      },
      () => {
        this.snack.open('No fue posible obtener la ubicación', 'Cerrar', { duration: 3000 });
      },
      {
        enableHighAccuracy: true,
        timeout: 8000,
        maximumAge: 30_000,
      }
    );
  }

  clearLocation(): void {
    this.attachedLocation.set(null);
  }

  isMine(senderId: string): boolean {
    return !!senderId && senderId === this.vm.myUserId();
  }

  async send(): Promise<void> {
    try {
      const text = this.draft();
      const files = this.selectedFiles();
      const location = this.attachedLocation();

      await this.facade.send({
        text,
        files: files.length ? files : undefined,
        location: location ?? undefined,
      });

      // Reset composer
      this.draft.set('');
      this.selectedFiles.set([]);
      this.attachedLocation.set(null);

      this.scheduleScrollToBottom();
    } catch (e: any) {
      this.snack.open(e?.message ?? 'No fue posible enviar el mensaje', 'Cerrar', { duration: 3500 });
    }
  }

  // ----------------------------
  // Scroll helper
  // ----------------------------
  private scheduleScrollToBottom(): void {
    if (this.scrollTimer) window.clearTimeout(this.scrollTimer);
    this.scrollTimer = window.setTimeout(() => this.scrollToBottom(), this.scrollTick);
  }

  private scrollToBottom(): void {
    const el = this.messagesBox?.nativeElement;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }
}
