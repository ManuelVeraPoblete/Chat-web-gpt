import { Routes } from '@angular/router';
import { LoginPage } from './presentation/login/login.page';

export const AUTH_ROUTES: Routes = [
  { path: '', component: LoginPage },
];
