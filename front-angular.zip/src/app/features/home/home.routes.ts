import { Routes } from '@angular/router';
import { HomePage } from './presentation/home.page';

export const HOME_ROUTES: Routes = [{ path: '', component: HomePage }];
